
#include <usbstk5515_led.h>
#include<stdio.h>
#include <usbstk5515.h>

Int16 led_test()
{
	Int16 j;
	USBSTK5515_LED_init();
	printf ("XF-LED (LED4) -blinking");
	for( j=0; j<20; j++)
    {
  USBSTK5515_LED_on (0);
  USBSTK5515_waitusec (10000);
  USBSTK5515_LED_off(0);
  USBSTK5515_waitusec (10000);
  }
   USBSTK5515_LED_on (0);
	printf ("XF-LED (LED4) -blinking");
	return 0;
}
