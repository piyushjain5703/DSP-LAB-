/*
 * main.c
 */
#include <stdio.h>
#include "usbstk5515.h"

extern Int16 led_test();


void main(void)
{
		int i;
		USBSTK5515_init();
		i = led_test();
		while(1);
}

