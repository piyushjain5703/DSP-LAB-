/*
 * main.c
 */
#include<stdio.h>
#include"usbstk5515.h"
int x[100];
static void dataInput();
void main()
{
  puts("SineWave example started./n");
	while(1)
	{
			dataInput();
	}
}
	
static void dataInput()
{
	return;
}
